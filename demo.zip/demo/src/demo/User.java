public class User {
    private String name;
    private Profile profile;

    public User(String name, Profile profile) {
        this.name = name;
        this.profile = profile;
    }

    public void printUserProfile() {
        System.out.println("User: " + name);
        System.out.println("Profile Picture: " + profile.getProfilePicture());
    }

    public static void main(String[] args) {
        Profile profile = null;
        User user = new User("Alice", profile);
        user.printUserProfile();
    }
}

class Profile {
    private String profilePicture;

    public Profile(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public String getProfilePicture() {
        return profilePicture;
    }
}
