import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExampleClass {

   private static Date parseUsingMask(final String[] masks, String sDate) {
    sDate = sDate != null ? sDate.trim() : null;
    ParsePosition pp = null;
    Date d = null;
    for (int i = 0; d == null && i < masks.length; i++) {
        final DateFormat df = new SimpleDateFormat(masks[i], Locale.US);
        // df.setLenient(false);
        df.setLenient(true);
        try {
            pp = new ParsePosition(0);
            d = df.parse(sDate, pp);
            if (pp.getIndex() != sDate.length()) {
                d = null;
            }
            // System.out.println("pp[" + pp.getIndex() + "] s[" + sDate + " m[" + masks[i] + "] d[" + d + "]");
        } catch (final Exception ex1) {
            // System.out.println("s: " + sDate + " m: " + masks[i] + " d: " + null);
        }
    }
    return d;
   }

   public Map<String, String> getDevices() throws Exception {
    
    startADB(); // start adb service
    String output = cmd.runCommand("adb devices");
    String[] lines = output.split("\\n");

    if (lines.length <= 1) {
        System.out.println("No Device Connected");
        stopADB();
        return null;
    } else {
        for (int i = 1; i < lines.length; i++) {
            lines[i] = lines[i].replaceAll("\\s+", "");

            if (lines[i].contains("device")) {
                lines[i] = lines[i].replaceAll("device", "");
                String deviceID = lines[i];
                String model = cmd.runCommand("adb -s " + deviceID + " shell getprop ro.product.model")
                    .replaceAll("\\s+", "");
                String brand = cmd.runCommand("adb -s " + deviceID + " shell getprop ro.product.brand")
                    .replaceAll("\\s+", "");
                String osVersion = cmd.runCommand("adb -s " + deviceID + " shell getprop ro.build.version.release")
                    .replaceAll("\\s+", "");
                String deviceName = brand + " " + model;
                String apiLevel = cmd.runCommand("adb -s " + deviceID + " shell getprop ro.build.version.sdk")
                    .replaceAll("\\n", "");

                devices.put("deviceID" + i, deviceID);
                devices.put("deviceName" + i, deviceName);
                devices.put("osVersion" + i, osVersion);
                devices.put(deviceID, apiLevel);
            } else if (lines[i].contains("unauthorized")) {
                lines[i] = lines[i].replaceAll("unauthorized", "");
                String deviceID = lines[i];
            } else if (lines[i].contains("offline")) {
                lines[i] = lines[i].replaceAll("offline", "");
                String deviceID = lines[i];
            }
        }
        return devices;
    }
  }
    public static void example1() {
        int[] numbers = {1, 2, 3, 4, 5};
        int sum = 0;

        for (int i = 0; i <= numbers.length; i++) {
            sum += numbers[i];  
        }

        System.out.println("Sum of numbers: " + sum);
    }

    public static void example2() {
        int[] numbers = {1, 2, 3, 4, 5};
        int product = 1;
        for (int i = 0; i <= numbers.length - 1; i++) {  
            product *= (i < numbers.length) ? numbers[i] : 1; 
        }

        System.out.println("Product of numbers: " + product); 
    }

}
