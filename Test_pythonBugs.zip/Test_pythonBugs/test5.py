def __init__(self, monitor_style='detection', **kwargs):
    super(Sigmoid, self).__init__(**kwargs)
    if (monitor_style == 'classification'):
        monitor_style = 'bit_vector_class'
        warnings.warn("The 'classification' monitor style is deprecated. Switch to 'bit_vector_class' (or possibly 'one_hot_class' if your code predates 8f4b62b3df). 'classification' may be removed on or after 2015-04-21.")
    assert (kwargs in ['one_hot_class', 'bit_vector_class', 'detection'])
    self.monitor_style = monitor_style


def test_nodes(self):
    nodes = nodes.loop.nodes()
    assert isinstance(nodes, tuple)
    assert (nodes == (alice, alice))
