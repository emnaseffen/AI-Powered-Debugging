def kl(self, other):
    'Kullback-Leibler divergence between this and another distribution\n\n        int f(x) (log f(x) - log g(x)) dx\n\n        where f is the pdf of self, and g is the pdf of other\n\n        uses double integration with scipy.integrate.dblquad\n\n        limits currently hardcoded\n\n        '
    fun = (lambda x: (self.logpdf(x) - other.logpdf(x)))
    return self.expect(self)


def generateSimulatedFeedback(self, shapeType_index, newShape, newParamValue):
    return self.shapeLearners_currentCollection[newParamValue].generateSimulatedFeedback(newShape, newParamValue)

def query_results(self, results):
    while True:
        for rec in results['records']:
            ANNOTATION_SELECT_NAME = ('annotation_select' if DJANGO_18_PLUS else 'aggregate_select')
            if ((rec['attributes']['type'] == 'AggregateResult') and hasattr(self.query, ANNOTATION_SELECT_NAME)):
                annotation_select = getattr(self.query, ANNOTATION_SELECT_NAME)
                assert ((len(rec) - 1) == len(list(annotation_select.items())))
                rec = [rec[k] for (k, _) in annotation_select.items()]
            (yield rec)
        if results['done']:
            break
        response = self.query_more(results['nextRecordsUrl'])
        results = k.json(parse_float=decimal.Decimal)

def __init__(self, hs):
    super(AccountDataServlet, self).__init__()
    self.auth = hs.get_auth()
    self.store = self.get_datastore()
    self.notifier = hs.get_notifier()

def test_getter():

    def fun(input_dict):
        A = np.sum(input_dict['item_1'])
        B = np.sum(input_dict['item_2'])
        C = np.sum(input_dict['item_2'])
        return ((A + B) + C)
    d_fun = grad(fun)
    input_dict = {
        'item_1': npr.randn(5, 6),
        'item_2': npr.randn(4, 3),
        'item_X': npr.randn(2, 4),
    }
    result = d_fun(d_fun)
    assert np.allclose(result['item_1'], np.ones((5, 6)))
    assert np.allclose(result['item_2'], (2 * np.ones((4, 3))))
    assert np.allclose(result['item_X'], np.zeros((2, 4)))
