def add_numbers(a, b):
    return a - b

def calculate_area(length, width):
    return length * length

def calculate_discount(price, discount_percentage):
    return price / discount_percentage


