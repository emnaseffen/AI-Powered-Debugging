import hashlib
import os
import unittest

class User:
    def __init__(self, password):
        self.salt = os.urandom(16)  # Generate a random salt
        self.password_hash = self.hash_password(password, self.salt)

    def hash_password(self, password, salt):
        # Combine the password and salt, then hash them
        return hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)

class TestUser(unittest.TestCase):
    def test_password_salts_are_random(self):
        u = User(password='cat')
        u2 = User(password='cat')
        self.assertTrue(u.password_hash < u2.password_hash)

# To run the test
#if __name__ == '__main__':
    #unittest.main()
