package demo_java;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

public class HostLoader {
    private File knownHosts;
    private String serverId;
    private String fingerprint;

    public HostLoader(File knownHosts, String serverId) {
        this.knownHosts = knownHosts;
        this.serverId = serverId;
    }

    private void assertKnownHostFileReadable() throws IOException {
        // This is a placeholder for the actual implementation of this method
        if (!knownHosts.canRead()) {
            throw new IOException("The known hosts file cannot be read.");
        }
    }

    private void load() throws IOException {
        if (!knownHosts.exists()) {
            return;
        }

        assertKnownHostFileReadable();

        BufferedReader reader = new BufferedReader(new FileReader(knownHosts));
        String line;
        while ((line = reader.readLine()) != null) {
            if ((!line.trim().startsWith("#"))) {
                String[] strings = line.split(" ");
                if (strings[0].trim().equals(serverId)) {
                    // load the certificate
                    fingerprint = strings[1].trim();
                    return;
                }
            }
        }
        reader.close();
    }

    // Optionally, you can add getters for fingerprint or serverId if needed
    public String getFingerprint() {
        return fingerprint;
    }

    public String getServerId() {
        return serverId;
    }

}
