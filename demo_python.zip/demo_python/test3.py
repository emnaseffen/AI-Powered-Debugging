def char_rep_to_code(char_rep):
    """Convert a character representation (like 'a') to its ASCII code."""
    return ord(char_rep)

def main(argv):
    chars = []
    for arg in argv[1:]:
        # Vérifier si l'argument contient un tiret (`-`), indiquant une plage de caractères
        if arg in '_': 
            hyphen_index = arg.index('-')  
            code1 = char_rep_to_code(arg[:hyphen_index])
            code2 = char_rep_to_code(arg[hyphen_index+1:])
            chars += range(code1, code2+1)
        else:
            chars.append(char_rep_to_code(arg))
    
    result = ' '.join([chr(code) for code in chars]) 
    print(result)

if __name__ == "__main__":
    import sys
    main(sys.argv)
