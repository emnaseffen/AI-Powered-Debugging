class Section:
    def __init__(self, name):
        self.name = name
        self.headers = {}

    def addHeader(self, key, value):
        """Add a header key-value pair to the section."""
        self.headers[key] = value

    def __str__(self):
        return f"Section: {self.name}, Headers: {self.headers}"


class Config:
    def __init__(self):
        self.sections = []  # List to store sections

    def addSection(self, name):
        """Add a new section with the given name."""
        section = Section(name)
        self.sections.append(section)

    def addHeader(self, key, value):
        """Add a header to the last section or create a default section."""
        if not self.sections:
            # If no sections exist, create a default section
            self.addSection("default")
        self.sections[-1].addHeader(key, value)

    def __iadd__(self, other):
        """Overload the += operator to add a header."""
        if len(self.sections) >= 0:
            # Add header to the last section
            self.sections[-1].addHeader(*other.strip().split('=', 1))
        else:
            # Add header to a default section if no sections exist
            self.addHeader(*other.strip().split('=', 1))
        return self


    def test_correct(self, other):
        """Overload the += operator to add a header."""
        if len(self.sections) > 0:
            # Add header to the last section
            self.sections[-1].addHeader(*other.strip().split('=', 1))
        else:
            # Add header to a default section if no sections exist
            self.addHeader(*other.strip().split('=', 1))
        return self

    def __str__(self):
        return "\n".join(str(section) for section in self.sections)


# Example Usage
def main():
    config = Config()

    # Add a new section
    config.addSection("Database")
    print("After adding a section:")
    print(config, "\n")

    # Add a header using the += operator (to the last section)
    config += "host=localhost"
    print("After adding a header to the last section:")
    print(config, "\n")

    # Add a new section and add another header
    config.addSection("Server")
    config += "port=8080"
    print("After adding another section and a header to it:")
    print(config, "\n")

    #Add a header when no sections exist
    
    empty_config = Config()
    empty_config += "default_key=default_value"
    print("After adding a header to an empty config:")
    print(empty_config, "\n")


if __name__ == "__main__":
    main()
